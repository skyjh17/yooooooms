$(document).ready(function(){
    lnb_menu();
    select();
    tab();
    datepicker();
    pop_confirm_pos();
    option_menu();
    file_box();
    
});

/* LNB */
function lnb_menu (){
    $(".lnb_menu ul li > a").click(function(){
        if($(this).hasClass("active")){
            $(this).removeClass("active");
        }else {
            $(this).addClass("active").parent("li").siblings("li").find("a").removeClass("active")
        }
    })
}

/* Design Select */
function select (){
  $(".select_btn").click(function(){
      if($(this).hasClass("active")){
          $(this).removeClass("active");
      }else {
          $(this).addClass("active").parent(".select_wrap").siblings().find(".select_btn").removeClass("active");
      }
  })

  $("#container .select_list li a,.popup_wrap .select_list li a").click(function(){
    var opt = $(this).text();
    var sel_btn = $(this).parents(".select_wrap > .select_list").prev('.select_btn');
    $('.select_list li a').not($(this)).removeClass('active');
    sel_btn.find('a').text(opt);
    sel_btn.removeClass("active");
    $(this).addClass("on").parent("li").siblings().find("a").removeClass("on").parents(".select_list").prev(".select_btn").removeClass("active");
  });
}

/* Tab */
function tab(){
    $(".tab_list li").click(function(){
        if($(this).is(".active")){    
        }else {            
            
            $(".tab_list li.active").removeClass("active");
            $(this).addClass("active");
            
            var indexTab = $(this).index();   
            var tab_cont = $(this).parents(".tab_list").next(".tab_cont_wrap").children(".tab_cont");             
            tab_cont.hide();
            tab_cont.eq(indexTab).show();
        }            
    });
}

function datepicker (){
    $( "#datepicker01,#datepicker02" ).datepicker({
        monthNamesShort: ['1','2','3','4','5','6','7','8','9','10','11','12'],
        monthNames: ['1월','2월','3월','4월','5월','6월','7월','8월','9월','10월','11월','12월'],
        dayNamesMin: ['일','월','화','수','목','금','토'],
        dayNames: ['일요일','월요일','화요일','수요일','목요일','금요일','토요일'],
        dateFormat: "yy.mm.dd"
  });
}

function pop_confirm_pos(){
    $(document).ready(function(){
        var pop_height = $(".type_confirm .popup").outerHeight();
        $(".type_confirm .popup").css("margin-top", '-' + (pop_height/2) + 'px');
    });
}

function option_menu (){
    $(".option_wrap .btn_wrap").click(function(){
        if($(this).next().is(".active")){    
            $(this).next().removeClass("active");
        }else {
            $(this).next().addClass("active").parents().siblings().find(".option_pop").removeClass("active");
        }            
    });
}

function file_box (){
    var fileTarget = $('#file'); 
    fileTarget.on('change', function(){
        var cur=$(".file_box input[type='file']").val();
         $(".upload_name").val(cur);
        $(".del").click(function(){
            $(".upload_name").val('선택된 파일 없음');
        });
    });
   
}
