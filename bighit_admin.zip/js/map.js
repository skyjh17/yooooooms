var myScroll;
function loaded() {
	//map 비율에 따라 100% 로 보여지게 하기 위함
	// 층 전체 너비 820px
	var m_w = $('.floor').outerWidth();
	var z = 1; //만약 100%로 보여지지 않는 페이지의 경우 z = 1 설정필요

	if ($('.map-wrap').parents('.tab-sub').length )
		z = $('.map-wrap').outerWidth() / m_w;
	
	myScroll = new IScroll('#map', {
		startX: 0,
		startY: 0,
		freeScroll: false,
		disablePointer: true,
		disableTouch: false,
		disableMouse: false,
		zoom: true,
		scrollX: true,
		scrollY: true,
		// mouseWheel: true,
		wheelAction: 'zoom',
		zoomMin:z,
		startZoom :z,

		// indicators: {
		// 	el: document.getElementById('minimap'),
		// 	interactive: true
		// }
	});
}
// document.getElementById('map').addEventListener("touchmove", function (event) { event.preventDefault (); }, {passive: false})

// zoom button
$('.btn-mapzoom').click(function(event){
	var now = myScroll.scale;
	var offset = 0.5;
	if($(this).hasClass('plus')){
		myScroll.zoom(now+offset);
	} else {
		myScroll.zoom(now-offset);
	}
 });